Lembre-se de alterar de criar um arquivo .env com as suas credenciais

npm i

node server.js
